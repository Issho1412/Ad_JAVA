package controller;

public interface EmployeeController {
    void deleteEmployee();
    void updateEmployee();
}
