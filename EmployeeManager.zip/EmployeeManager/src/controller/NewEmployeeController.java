package controller;

public interface NewEmployeeController {
    void newEmployee();
}
