package controller;

public interface UpdateEmployeeController {
    void updateMEmployee();
}
